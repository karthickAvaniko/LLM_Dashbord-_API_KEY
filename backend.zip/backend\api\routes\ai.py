from fastapi import APIRouter, Header, Form, File, UploadFile, HTTPException, Depends
import httpx
import base64
from backend.core.config import settings
from backend.schemas.api_key import ChatRequest, GenerateRequest
from backend.api.dependencies import verify_key, log_usage

router = APIRouter()

@router.post("/v1/chat/completions")
async def chat(req: ChatRequest, key_row: dict = Depends(verify_key)):
    payload = {"model": settings.MODEL_NAME, "messages": req.messages, "max_tokens": req.max_tokens, "temperature": req.temperature}
    if req.enable_thinking:
        payload["chat_template_kwargs"] = {"enable_thinking": True}
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(f"{settings.VLLM_URL}/v1/chat/completions", json=payload)
            result = resp.json()
        usage = result.get("usage", {})
        log_usage(key_row, "/v1/chat/completions", usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0))
        return result
    except Exception as e:
        log_usage(key_row, "/v1/chat/completions", 0, 0, "error")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/v1/generate")
async def generate(req: GenerateRequest, key_row: dict = Depends(verify_key)):
    messages = []
    if req.system:
        messages.append({"role": "system", "content": req.system})
    messages.append({"role": "user", "content": req.prompt})
    payload = {
        "model": settings.MODEL_NAME,
        "messages": messages,
        "max_tokens": req.max_tokens,
        "temperature": req.temperature,
    }
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(f"{settings.VLLM_URL}/v1/chat/completions", json=payload)
            raw = resp.json()
        usage = raw.get("usage", {})
        choice = raw["choices"][0]
        log_usage(key_row, "/v1/generate", usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0))
        return {
            "id": raw.get("id", ""),
            "model": settings.MODEL_DISPLAY_NAME,
            "text": choice["message"]["content"],
            "finish_reason": choice.get("finish_reason", "stop"),
            "usage": {
                "input_tokens": usage.get("prompt_tokens", 0),
                "output_tokens": usage.get("completion_tokens", 0),
                "total_tokens": usage.get("total_tokens", 0),
            }
        }
    except Exception as e:
        log_usage(key_row, "/v1/generate", 0, 0, "error")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/v1/vision/analyze")
async def vision_analyze(
    file: UploadFile = File(...),
    prompt: str = Form(default="Extract all invoice data as JSON. Return only valid JSON."),
    enable_thinking: bool = Form(default=False),
    key_row: dict = Depends(verify_key)
):
    image_bytes = await file.read()
    image_b64 = base64.b64encode(image_bytes).decode()
    mime = file.content_type or "image/jpeg"
    messages = [{"role": "user", "content": [
        {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{image_b64}"}},
        {"type": "text", "text": prompt}
    ]}]
    payload = {"model": settings.MODEL_NAME, "messages": messages, "max_tokens": 4096, "temperature": 0}
    if enable_thinking:
        payload["chat_template_kwargs"] = {"enable_thinking": True}
    try:
        async with httpx.AsyncClient(timeout=180) as client:
            resp = await client.post(f"{settings.VLLM_URL}/v1/chat/completions", json=payload)
            result = resp.json()
        usage = result.get("usage", {})
        log_usage(key_row, "/v1/vision/analyze", usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0))
        content = result["choices"][0]["message"]["content"]
        return {"result": content, "usage": usage}
    except Exception as e:
        log_usage(key_row, "/v1/vision/analyze", 0, 0, "error")
        raise HTTPException(status_code=500, detail=str(e))
