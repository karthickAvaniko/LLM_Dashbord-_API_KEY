from fastapi import APIRouter, Depends, HTTPException
import secrets, json
from datetime import datetime, timedelta
from typing import Optional
from backend.core.database import get_db
from backend.core.security import hash_password
from backend.schemas.api_key import RegisterKeyRequest, CreateKeyRequest
from backend.api.dependencies import require_user_session, require_admin_session

router = APIRouter()

# ── Public registration (no auth) — Gemini-style key request ──
@router.post("/v1/keys/register")
def register_key(req: RegisterKeyRequest):
    """Public endpoint — no JWT needed.
    Creates a user (if email new) and returns a fresh API key.
    """
    conn = get_db()
    # Find or auto-create user
    user_row = conn.execute("SELECT * FROM users WHERE email=?", (req.email,)).fetchone()
    if not user_row:
        # Auto-register with random password (user can reset later)
        random_pw = secrets.token_urlsafe(16)
        conn.execute(
            "INSERT INTO users (email, password_hash, name, role, created_at) VALUES (?,?,?,?,?)",
            (req.email, hash_password(random_pw), req.name or req.email.split("@")[0], "user", datetime.now().isoformat())
        )
        conn.commit()
        user_row = conn.execute("SELECT * FROM users WHERE email=?", (req.email,)).fetchone()

    # Generate key
    key = "ak_" + secrets.token_urlsafe(32)
    conn.execute(
        """INSERT INTO api_keys
           (user_id, key, name, description, environment, created_at,
            rate_limit, token_budget, allowed_endpoints)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (user_row["id"], key, req.name or "default", "auto-generated via public registration",
         "production", datetime.now().isoformat(), 200, 100000, "[]")
    )
    conn.commit()
    conn.close()
    return {
        "api_key": key,
        "key": key,
        "name": req.name,
        "email": req.email,
        "rate_limit": 200,
        "token_budget": 100000,
        "created_at": datetime.now().isoformat(),
    }

@router.post("/keys/create")
def create_key(req: CreateKeyRequest, payload: dict = Depends(require_user_session)):
    key = "ak_" + secrets.token_urlsafe(32)
    conn = get_db()
    user_row = conn.execute("SELECT id FROM users WHERE email=? AND is_active=1", (payload["email"],)).fetchone()
    if not user_row:
        conn.close()
        raise HTTPException(status_code=400, detail="Invalid active user session")

    expires_at = None
    if req.expires_in_days and req.expires_in_days > 0:
        expires_at = (datetime.now() + timedelta(days=req.expires_in_days)).isoformat()

    allowed_str = json.dumps(req.allowed_endpoints or [])

    conn.execute(
        """INSERT INTO api_keys
           (user_id, key, name, description, environment, created_at, expires_at,
            rate_limit, token_budget, allowed_endpoints)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (user_row["id"], key, req.name, req.description or "", req.environment or "production",
         datetime.now().isoformat(), expires_at, req.rate_limit, req.token_budget or 0, allowed_str)
    )
    conn.commit()
    conn.close()
    return {
        "api_key": key,
        "name": req.name,
        "environment": req.environment,
        "rate_limit": req.rate_limit,
        "token_budget": req.token_budget,
        "expires_at": expires_at,
    }

@router.get("/keys/list")
def list_keys(payload: dict = Depends(require_user_session)):
    conn = get_db()
    if payload.get("role") == "admin":
        rows = conn.execute("SELECT k.*, u.email as owner_email FROM api_keys k JOIN users u ON k.user_id = u.id").fetchall()
    else:
        user_row = conn.execute("SELECT id FROM users WHERE email=? AND is_active=1", (payload["email"],)).fetchone()
        rows = conn.execute("SELECT k.*, u.email as owner_email FROM api_keys k JOIN users u ON k.user_id = u.id WHERE k.user_id=?", (user_row["id"],)).fetchall()
    conn.close()
    return {"keys": [dict(r) for r in rows]}

@router.delete("/keys/{key_id}")
def delete_key(key_id: int, payload: dict = Depends(require_user_session)):
    conn = get_db()
    if payload.get("role") == "admin":
        conn.execute("UPDATE api_keys SET is_active=0 WHERE id=?", (key_id,))
    else:
        user_row = conn.execute("SELECT id FROM users WHERE email=? AND is_active=1", (payload["email"],)).fetchone()
        conn.execute("UPDATE api_keys SET is_active=0 WHERE id=? AND user_id=?", (key_id, user_row["id"]))
    conn.commit()
    conn.close()
    return {"message": "Key deactivated"}

@router.get("/usage")
def get_usage(api_key_id: Optional[int] = None, payload: dict = Depends(require_user_session)):
    conn = get_db()
    if payload.get("role") == "admin":
        if api_key_id:
            rows = conn.execute("SELECT l.*, k.key as actual_key FROM usage_logs l JOIN api_keys k ON l.api_key_id = k.id WHERE l.api_key_id=? ORDER BY l.timestamp DESC LIMIT 100", (api_key_id,)).fetchall()
        else:
            rows = conn.execute("SELECT l.*, k.key as actual_key FROM usage_logs l JOIN api_keys k ON l.api_key_id = k.id ORDER BY l.timestamp DESC LIMIT 100").fetchall()
        summary = conn.execute("""
            SELECT k.id as api_key_id, k.key as api_key, k.name, k.total_requests, k.total_tokens, k.total_cost, u.email as owner
            FROM api_keys k JOIN users u ON k.user_id = u.id
        """).fetchall()
    else:
        user_row = conn.execute("SELECT id FROM users WHERE email=?", (payload["email"],)).fetchone()
        user_id = user_row["id"]
        if api_key_id:
            rows = conn.execute("SELECT l.*, k.key as actual_key FROM usage_logs l JOIN api_keys k ON l.api_key_id = k.id WHERE l.api_key_id=? AND k.user_id=? ORDER BY l.timestamp DESC LIMIT 100", (api_key_id, user_id)).fetchall()
        else:
            rows = conn.execute("SELECT l.*, k.key as actual_key FROM usage_logs l JOIN api_keys k ON l.api_key_id = k.id WHERE k.user_id=? ORDER BY l.timestamp DESC LIMIT 100", (user_id,)).fetchall()
        summary = conn.execute("""
            SELECT k.id as api_key_id, k.key as api_key, k.name, k.total_requests, k.total_tokens, k.total_cost, u.email as owner
            FROM api_keys k JOIN users u ON k.user_id = u.id WHERE k.user_id=?
        """, (user_id,)).fetchall()
    conn.close()
    return {"logs": [dict(r) for r in rows], "summary": [dict(r) for r in summary]}
