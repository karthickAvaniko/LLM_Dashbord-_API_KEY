import os
from pathlib import Path

# Load .env file if present (local dev)
_ENV_FILE = Path(__file__).resolve().parent.parent.parent / ".env"
if _ENV_FILE.exists():
    for line in _ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

# RunPod-ல /workspace = Network Volume (persistent)
# Local dev-ல project folder-ல இருக்கும்
_IS_RUNPOD = os.path.isdir("/workspace")
_BASE = "/workspace" if _IS_RUNPOD else os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

class Settings:
    PROJECT_NAME: str = "Avaniko AI API Gateway"

    # vLLM server (RunPod public proxy URL or local localhost)
    # Format: https://<POD_ID>-8000.proxy.runpod.net  (NO trailing slash)
    VLLM_URL: str = os.getenv("VLLM_URL", "http://localhost:8000")

    # The model name vLLM was started with (must match --served-model-name)
    # On RunPod we use --served-model-name qwen3.6-35b
    MODEL_NAME: str = os.getenv("MODEL_NAME", "qwen3.6-35b")

    # Display name shown to users in the UI
    MODEL_DISPLAY_NAME: str = os.getenv("MODEL_DISPLAY_NAME", "Qwen3.6-35B-A3B")

    ADMIN_SECRET: str = os.getenv("ADMIN_SECRET", "admin_secret_change_this")
    JWT_SECRET: str = os.getenv("JWT_SECRET", "avaniko_jwt_secret_2025_change_this")
    JWT_ALGORITHM: str = "HS256"
    DB_PATH: str = os.path.join(_BASE, "storage", "gateway_v2.db")
    DIST_DIR: str = os.path.join(_BASE, "dist")

    # Pricing (per 1000 tokens)
    PRICE_PROMPT_1K: float = 0.0015
    PRICE_COMPLETION_1K: float = 0.0020

    # Admin credentials (seeded on first startup)
    ADMIN_EMAIL: str = "karthick.murugan@avaniko.com"
    ADMIN_PASSWORD: str = "Avan@123"
    ADMIN_NAME: str = "Karthick Murugan"

settings = Settings()
