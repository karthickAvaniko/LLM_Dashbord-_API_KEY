import sqlite3
import os
from datetime import datetime
from backend.core.config import settings
from backend.core.security import hash_password

def get_db():
    os.makedirs(os.path.dirname(settings.DB_PATH), exist_ok=True)
    conn = sqlite3.connect(settings.DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def _add_column_if_missing(conn, table: str, column: str, col_type: str):
    """Safely add a column only if it does not already exist (SQLite migration helper)."""
    cols = [row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()]
    if column not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type}")

def init_db():
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            email         TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            name          TEXT NOT NULL,
            role          TEXT DEFAULT 'user',
            created_at    TEXT NOT NULL,
            is_active     INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS api_keys (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id        INTEGER,
            key            TEXT UNIQUE NOT NULL,
            name           TEXT NOT NULL,
            description    TEXT DEFAULT '',
            environment    TEXT DEFAULT 'production',
            created_at     TEXT NOT NULL,
            expires_at     TEXT DEFAULT NULL,
            is_active      INTEGER DEFAULT 1,
            rate_limit     INTEGER DEFAULT 500,
            token_budget   INTEGER DEFAULT 0,
            allowed_endpoints TEXT DEFAULT '',
            total_requests INTEGER DEFAULT 0,
            total_tokens   INTEGER DEFAULT 0,
            total_cost     REAL DEFAULT 0.0
        );
        CREATE TABLE IF NOT EXISTS usage_logs (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            api_key_id        INTEGER,
            endpoint          TEXT NOT NULL,
            prompt_tokens     INTEGER DEFAULT 0,
            completion_tokens INTEGER DEFAULT 0,
            cost              REAL DEFAULT 0.0,
            timestamp         TEXT NOT NULL,
            status            TEXT DEFAULT 'success'
        );
    """)

    # ── Safe migration: add any columns missing in older DB files on disk ──
    _add_column_if_missing(conn, "api_keys", "user_id",           "INTEGER")
    _add_column_if_missing(conn, "api_keys", "description",       "TEXT DEFAULT ''")
    _add_column_if_missing(conn, "api_keys", "environment",       "TEXT DEFAULT 'production'")
    _add_column_if_missing(conn, "api_keys", "expires_at",        "TEXT DEFAULT NULL")
    _add_column_if_missing(conn, "api_keys", "token_budget",      "INTEGER DEFAULT 0")
    _add_column_if_missing(conn, "api_keys", "allowed_endpoints", "TEXT DEFAULT ''")
    _add_column_if_missing(conn, "api_keys", "total_requests",    "INTEGER DEFAULT 0")
    _add_column_if_missing(conn, "api_keys", "total_tokens",      "INTEGER DEFAULT 0")
    _add_column_if_missing(conn, "api_keys", "total_cost",        "REAL DEFAULT 0.0")
    _add_column_if_missing(conn, "usage_logs", "api_key_id",        "INTEGER")
    _add_column_if_missing(conn, "usage_logs", "prompt_tokens",     "INTEGER DEFAULT 0")
    _add_column_if_missing(conn, "usage_logs", "completion_tokens", "INTEGER DEFAULT 0")
    _add_column_if_missing(conn, "usage_logs", "cost",              "REAL DEFAULT 0.0")
    _add_column_if_missing(conn, "usage_logs", "status",            "TEXT DEFAULT 'success'")
    conn.commit()

    # ── Seed admin user ──
    try:
        conn.execute(
            "INSERT OR IGNORE INTO users (email, password_hash, name, role, created_at) VALUES (?,?,?,?,?)",
            (settings.ADMIN_EMAIL, hash_password(settings.ADMIN_PASSWORD), settings.ADMIN_NAME, "admin", datetime.now().isoformat())
        )
        conn.commit()
    except Exception:
        pass
    conn.close()
